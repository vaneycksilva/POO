package questao03;
import java.util.*;


public class Totens implements Observer {

	Subject subject;
	
	List<Observer> listaDeVoos;

	public Totens(){
		
		listaDeVoos = new ArrayList<Observer>();
		
	}
	
	
	@Override
	public  void update() {
		
		subject.getData();
		
	}
	
	
	@Override
	public String toString() {
		
		String string = "";
		for (Observer observer : listaDeVoos) {
			System.out.println(string + observer);
		}
		
		return string;
	}
	
}
