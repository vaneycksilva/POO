package questao03;

public class Voo {
	
	
	private int numeroDoVoo;
	private String empresa;
	private String horario;
	private boolean statusVoo;
	
	public Voo(int num, String empresa) {
		
		this.numeroDoVoo = num;
		this.empresa = empresa;
	}

	
	
	
	
	public int getNumeroDoVoo() {
		return numeroDoVoo;
	}

	public void setNumeroDoVoo(int numeroDoVoo) {
		this.numeroDoVoo = numeroDoVoo;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public boolean isStatusVoo() {
		return statusVoo;
	}

	public void setStatusVoo(boolean statusVoo) {
		this.statusVoo = statusVoo;
	}
	
	
}
