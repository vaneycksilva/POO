package questao03;

public interface Observer {
	
	void update();
	
}
