package questao03;

import java.util.ArrayList;
import java.util.List;

public class BaseDeDados implements Subject {

	
	private List<Observer> observadores;
	private List<Voo> todosOsVoos;
	
	
	public BaseDeDados() {
		
		observadores = new ArrayList<Observer>();
		todosOsVoos = new ArrayList<Voo>();
	}
	
	@Override
	public void addObserver(Observer obs) {
		observadores.add(obs);
		notifyObservers();
	}

	@Override
	public void removeObserver(Observer obs) {
		
		observadores.remove(obs);

	}

	@Override
	public void notifyObservers() {
		for (Observer observer : observadores) {
			observer.update();
		}

	}

	@Override
	public Object getData() {
		
		return this.todosOsVoos;
	}
	
	

	public void addVoos(Voo voo){
		
		todosOsVoos.add(voo);
		notifyObservers();
	}
	
	// avisar aos totens??
	public void removeVoo(Voo voo){
		
		todosOsVoos.remove(voo);
		
	}
	
	
	
	
}


