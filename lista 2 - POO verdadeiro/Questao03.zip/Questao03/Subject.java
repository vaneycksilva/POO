package questao03;

public interface Subject {

	void addObserver(Observer obs);
	
	void removeObserver(Observer obs);
	
	void notifyObservers();
	
	Object getData();
}
