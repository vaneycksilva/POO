package questao01;

public class InsertionSort implements Sort {

	@Override
	public void sort(int... nums) {
		
		
		for (int i = 0; i < nums.length; i++) {
			int a = nums[i];
			 for (int j = i - 1; j >= 0 && nums[j] > a; j--) {
				nums[j+1] = nums[j];
				nums[j] = a;
			}
			
		}
		
		
	}

}
