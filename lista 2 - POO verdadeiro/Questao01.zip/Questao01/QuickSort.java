package questao01;

public class QuickSort implements Sort {

	@Override
	public void sort(int... nums) {
		
		quickSort(nums, 0, nums.length-1);
		
	}
		
		private void quickSort(int[] nums,int inicio, int fim ){
			
			if(inicio<fim){
				int q = partition(nums,inicio,fim);
				quickSort(nums,inicio,q-1);
				quickSort(nums,q+1,fim);
			}
		}
		
		//Patition
		private  int partition(int[] nums, int inicio, int fim){
			int x = nums[inicio];
			int a = inicio+1;
			int b = fim;
			
			while(true){
				while((a <= fim) && (nums[a] <= x) ){
					++a;
				}
				while( (b >= inicio+1) && (nums[b] >= x)){
					--b;
				}
				
				if(a<=b){
					swap(nums,a,b);
				}else{
					swap(nums,inicio,b);
					return b;
				}
			}
		}
		//Swap
		private void swap(int[] nums,int a, int b) {
			int tmp = nums[a];
			nums[a] = nums[b];
			nums[b] = tmp;
		}


		
		
}


