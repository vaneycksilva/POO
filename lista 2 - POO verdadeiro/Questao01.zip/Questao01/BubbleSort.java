package questao01;

public class BubbleSort implements Sort {

	public void sort(int... nums) {
		
		int aux =0;
		for (int i = 0; i < nums.length; i++) {
			for (int j = 0; j < nums.length-1; j++) {
				if (nums[j] > nums[j+1]) {
					aux = nums[j];
					nums[j]=nums[j+1];
					nums[j+1] = aux;
				} 
			}
		}
		
		
	}

}
