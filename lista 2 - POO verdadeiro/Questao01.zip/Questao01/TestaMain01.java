package questao01;

import java.util.Random;

public class TestaMain01 {

	public static void main(String[] args) {
		
		long tempoInicio1 = System.currentTimeMillis();
		
		Sort  bubble = new BubbleSort();
		
		int tamanho = 1000;
		
		int[] array1 = new int[tamanho];
		
		//gera numeros aleatorios
		Random random = new Random();
		
		// gera array de numeros aleatorios
		for (int i = 0;  i< tamanho; i++) {
			array1[i] = random.nextInt(tamanho);
		}
		
		
		bubble.sort(array1);
		
		for (int i = 0; i < array1.length; i++) {
			System.out.println(array1[i]);
			//System.out.println(random);
		}
		
		//quick
		long tempoInicio2 = System.currentTimeMillis();
		
		Sort  quick = new QuickSort();
		
		int tamanho2 = 1000;
		
		int[] array2 = new int[tamanho];
		
		//gera numeros aleatorios
		Random random2 = new Random();
		
		// gera array de numeros aleatorios
		for (int i = 0;  i< tamanho; i++) {
			array2[i] = random.nextInt(tamanho);
		}
		
		
		quick.sort(array2);
		
		for (int i = 0; i < array2.length; i++) {
			System.out.println(array2[i]);
			//System.out.println(random);
		}
		
		
		// insertion
		
	long tempoInicio3 = System.currentTimeMillis();
		
		Sort  insertion = new InsertionSort();
		
		int tamanho3 = 1000;
		
		int[] array3 = new int[tamanho];
		
		//gera numeros aleatorios
		Random random3 = new Random();
		
		// gera array de numeros aleatorios
		for (int i = 0;  i< tamanho; i++) {
			array3[i] = random.nextInt(tamanho);
		}
		
		insertion.sort(array3);
		
		for (int i = 0; i < array3.length; i++) {
			System.out.println(array3[i]);
			//System.out.println(random);
		}
		
		
		
		System.out.println("\nTempo em milisegundos do Bubble: "+(System.currentTimeMillis()-tempoInicio1));
		System.out.println("Tempo em milisegundos do Quick: "+(System.currentTimeMillis()-tempoInicio2));
		System.out.println("Tempo em milisegundos do Insertion: "+(System.currentTimeMillis()-tempoInicio3));
		System.out.println("Como o meu merge ta bugado o mais r�pido foi o InsertionSort");
		
	}

}
