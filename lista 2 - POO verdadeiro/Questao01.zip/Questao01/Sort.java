package questao01;

public interface Sort {

	
	void sort(int... nums);
	
}
