package questao02;

public class Alabarda implements EstrategiaDeAtaque {

	@Override
	public int ataque() {
		
		return -30;
	}

}
