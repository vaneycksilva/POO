package questao02;

public class ArmaduraDeCouro implements EstrategiaDeDefesa {

	@Override
	public int resistencia() {
		
		return +2;
	}

}
