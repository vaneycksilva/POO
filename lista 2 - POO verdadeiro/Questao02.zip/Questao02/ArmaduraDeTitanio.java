package questao02;

public class ArmaduraDeTitanio implements EstrategiaDeDefesa {

	@Override
	public int resistencia() {

		return +15;
	}

}
