package questao02;

public class TestaQuestao02 {

	public static void main(String[] args) {

		Guerreiro guerreiro1 =  new Guerreiro("Mouro");
		EstrategiaDeAtaque arma1 = new Machado();
		guerreiro1.setArma(arma1);
		EstrategiaDeDefesa armadura1 = new ArmaduraDeTitanio();
		guerreiro1.setArmadura(armadura1);
		
		
		Guerreiro guerreiro2 =  new Guerreiro("Lula");
		EstrategiaDeAtaque arma2 = new Alabarda();
		guerreiro2.setArma(arma2);
		EstrategiaDeDefesa armadura2 = new ArmaduraDeTitanio();
		guerreiro2.setArmadura(armadura2);
		
		
		guerreiro1.atacar(guerreiro2);
		guerreiro2.atacar(guerreiro1);
		
		guerreiro1.atacar(guerreiro2);
		guerreiro2.atacar(guerreiro1);
		
		guerreiro1.atacar(guerreiro2);
		guerreiro2.atacar(guerreiro1);
		
		guerreiro1.atacar(guerreiro2);
		//guerreiro2.atacar(guerreiro1);
		
		//guerreiro1.atacar(guerreiro2);
		//guerreiro2.atacar(guerreiro1);
		
		
		System.out.println("Life do "+guerreiro1.getNome()+": "+guerreiro1.getVida());
		System.out.println("Life do "+guerreiro2.getNome()+": "+guerreiro2.getVida());
		
		
		if (guerreiro1.getVida() <= 0 || guerreiro1.getVida()<=0) {
			System.out.println("ningu�m venceu");
		}else if(guerreiro2.getVida()<=0){
			System.out.println(guerreiro1.getNome()+" venceu");
		}else if( guerreiro1.getVida() <= 0 ){
			System.out.println(guerreiro2.getNome()+" venceu");
		}
		
	}

}
