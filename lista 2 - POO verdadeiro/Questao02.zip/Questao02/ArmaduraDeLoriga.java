package questao02;

public class ArmaduraDeLoriga implements EstrategiaDeDefesa {

	@Override
	public int resistencia() {
		
		return +5;
	}

}
