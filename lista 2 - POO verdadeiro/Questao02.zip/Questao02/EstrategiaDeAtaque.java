package questao02;

public interface EstrategiaDeAtaque {
	
	int ataque();
	
}
