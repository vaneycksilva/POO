package questao02;

public interface EstrategiaDeDefesa {

	int resistencia();
	
}
