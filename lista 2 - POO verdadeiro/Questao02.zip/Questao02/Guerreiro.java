package questao02;

public class Guerreiro {
	
	private String nome;
	private int vida;
	private EstrategiaDeAtaque arma;
	private EstrategiaDeDefesa armadura;
	
	
	public Guerreiro(String nome){
		
		this.nome = nome;
		this.vida = 100;
		this.arma= arma;
		this.armadura = armadura;
	}
	
	
	public void atacar(Guerreiro oponente){
		
		
		oponente.setVida(getVida() - Math.max(oponente.arma.ataque(), oponente.armadura.resistencia()));
		
		/*
		if (oponente.getVida() < 0) {
			System.out.println(getNome()+"ganhou");
		}else if(getVida() < 0){
			System.out.println(oponente.nome+"ganhou");
		}else{
			System.out.println("Ningu�m vence");
		}
		*/
	}
	
	
	public String getNome() {
		return nome;
	}
	
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	public int getVida() {
		return vida;
	}
	
	
	public void setVida(int vida) {
		this.vida = vida;
	}
	
	
	public EstrategiaDeAtaque getArma() {
		return arma;
	}
	
	
	public void setArma(EstrategiaDeAtaque arma) {
		this.arma = arma;
	}
	
	
	public EstrategiaDeDefesa getArmadura() {
		return armadura;
	}
	
	
	public void setArmadura(EstrategiaDeDefesa armadura) {
		this.armadura = armadura;
	}
}
