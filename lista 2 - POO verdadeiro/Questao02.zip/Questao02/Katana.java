package questao02;

public class Katana implements EstrategiaDeAtaque {

	@Override
	public int ataque() {
		
		return -25;
	}

}
