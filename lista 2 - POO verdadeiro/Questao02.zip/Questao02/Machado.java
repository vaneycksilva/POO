package questao02;

public class Machado implements EstrategiaDeAtaque {

	@Override
	public int ataque() {

		return -40;
	}

}
